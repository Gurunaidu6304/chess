// init the FB JS SDK
FB.init({
    appId: '602807239779512', // App ID from the app dashboard
    status: true, // Check Facebook Login status
    xfbml: true                                  // Look for social plugins on the page
});